//
//  AppDelegate.h
//   SecureEnclaveDemo
//
//  Created by Tanvi Jain on 2020-09-18.
//  Copyright © 2020 Tanvi Jain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

