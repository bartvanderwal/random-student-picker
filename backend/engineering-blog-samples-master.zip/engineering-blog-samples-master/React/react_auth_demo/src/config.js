const config = {
    APP_NAME: 'lrcli',
    API_KEY: '548ea7a1-4f25-4fad-8663-10ef68b94e3b',
  };
  export default config;