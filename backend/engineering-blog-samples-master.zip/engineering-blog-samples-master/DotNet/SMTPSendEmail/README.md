## How to send emails through C#/.NET using SMTP

## Prerequisites
* Basic knowledge about the C#/.NET and it's application IDE

## How to Start

1. Clone the repo.
2. Go to directory `DotNet\SMTPSendEmail`
3. Open `EmailSendingUtility.sln` file in IDE.
4. Add the required information to send the Email in `EmailSendingUtility\Program.cs` file.
5. Build and Run the Project.
