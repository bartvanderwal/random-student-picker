module.exports = {
  'facebookAuth': {
    'clientID': '<APP_ID>', // your App ID
    'clientSecret': '<APP_SECRET>', // your App Secret
    'callbackURL': 'http://localhost:3000/auth/facebook/callback'
  }
}

