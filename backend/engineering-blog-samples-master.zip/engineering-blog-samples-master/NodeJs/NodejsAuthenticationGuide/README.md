### Password Hashing in NodeJS using Bcrypt

#### Prerequisites

1. Basic Understanding of Node and JavaScript.
2. Node and NPM installed.

#### How to Start

1. Clone the repo. 
2. Run `npm install`
3. Run `node server.js`
4. Server will be running at `locahost:5000`
