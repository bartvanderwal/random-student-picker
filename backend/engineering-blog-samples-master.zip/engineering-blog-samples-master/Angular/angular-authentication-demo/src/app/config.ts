const config = {
  APP_NAME: 'dev-wouhvz3ow',
  API_KEY: '8ac9cf77-5501-4e47-b114-9e2eaaae86b9',
};

export default config;
