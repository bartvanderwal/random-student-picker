export interface Profile {
  Email: {
    Type: string;
    Value: string;
  }[];
}
