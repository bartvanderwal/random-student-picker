# Authentication with Flask and JWT

## Development server

- Create a virtual environment, activate it and install the dependencies.
- Run `flask run` to start the development server.
- Navigate to http://localhost:5000/. The app will automatically reload if you change any of the source files.

© 2021 GitHub, Inc.