export class UserDto {
    email: string;
    password: string;
  }