# Contributing to Engineering Blog Samples

First of all, we appreciate your efforts in contributing to this repository! But as per present guidelines, we are not accepting any pull requests from outside our organization. 
