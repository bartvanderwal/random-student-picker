import React from 'react';

import './App.css';
import FSItem from './components/FSItem';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <FSItem />
      </header>
    </div>
  );
}

export default App;
