### Web Workers: A Simple Introduction

##### This is the code repository for the blog post published on [LoginRadius Engineering Blog](https://www.loginradius.com/engineering/blog/adding-multi-threading-to-javascript-using-web-workers/).

#### Prerequisites

- Basic Understanding JavaScript.


#### How to Start

1. Clone the repo. 
2. Go to the directory `JavaScript/WebWorkers`
3. Open `index.html` in your browser and see instructions to run different scripts in `index.html`
