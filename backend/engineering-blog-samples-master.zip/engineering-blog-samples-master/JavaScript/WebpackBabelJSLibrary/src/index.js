import capital from './capital';
import addDOMContent from './addDOMContent';

export { capital, addDOMContent };
