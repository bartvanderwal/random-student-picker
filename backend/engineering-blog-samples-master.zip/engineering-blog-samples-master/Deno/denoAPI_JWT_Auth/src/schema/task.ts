export interface TaskSchema {
    name: string;
    isCompleted: boolean;
  } 