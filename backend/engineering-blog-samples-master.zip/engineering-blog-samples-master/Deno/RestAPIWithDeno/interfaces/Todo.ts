export default interface Todo {
  id: string,
  task: string,
  done: boolean,
}